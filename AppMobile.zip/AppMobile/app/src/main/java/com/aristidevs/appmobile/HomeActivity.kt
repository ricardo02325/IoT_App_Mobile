package com.aristidevs.appmobile

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class HomeActivity : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_home)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val txtpassword = findViewById<TextView>(R.id.txt_password)
        val txtregister = findViewById<TextView>(R.id.txt_register)

        txtpassword.setOnClickListener { ForgotPasswordActivityApp() }
        txtregister.setOnClickListener { RegisterActivityApp() }

    }

    private fun RegisterActivityApp() {
        val intent = Intent(this, registerActivity::class.java)
        startActivity(intent)
    }

    private fun ForgotPasswordActivityApp() {
        val intent = Intent(this, ForgotPasswordActivity::class.java)
        startActivity(intent)
    }
}