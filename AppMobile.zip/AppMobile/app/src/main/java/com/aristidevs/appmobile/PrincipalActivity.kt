package com.aristidevs.appmobile

import android.os.Bundle
import android.content.Intent
import android.widget.Button
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class PrincipalActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_principal)
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets



        }

        supportActionBar?.hide()

        val BtnLogin = findViewById<Button>(R.id.btn_login)
        val BtnRegister = findViewById<Button>(R.id.btn_register)

        BtnLogin.setOnClickListener { HomeActivityApp() }
        BtnRegister.setOnClickListener { RegisterActivityApp() }

    }

    private fun RegisterActivityApp() {
        val intent = Intent(this, registerActivity::class.java)
        startActivity(intent)
    }

    private fun HomeActivityApp(){
        val intent = Intent(this, HomeActivity::class.java)
        startActivity(intent)
    }

}